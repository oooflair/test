package com.businesslogic;

// Single controller file - all API endpoints in one place
// Much simpler than having separate controllers

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")  // Simple CORS for frontend
class ApiController {
    
    @Autowired
    private MainService service;
    
    // Execute a natural language query
    @PostMapping("/query")
    public ResponseEntity<QueryResponse> executeQuery(@Valid @RequestBody QueryRequest request) {
        try {
            QueryResponse response = service.processQuery(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            QueryResponse errorResponse = new QueryResponse();
            errorResponse.setStatus("ERROR");
            errorResponse.setErrorMessage("Server error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    
    // Download Excel (GET - using cached query)
    @GetMapping("/query/{queryId}/download")
    public ResponseEntity<byte[]> downloadExcel(@PathVariable String queryId) {
        try {
            QueryResponse response = service.getCachedQuery(queryId);
            if (response == null) {
                return ResponseEntity.notFound().build();
            }
            
            byte[] excelData = service.exportToExcel(response.getColumns(), response.getRows());
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "query_results.xlsx");
            
            return ResponseEntity.ok().headers(headers).body(excelData);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    // Download Excel (POST - using direct data, no AI re-query!)
    @PostMapping("/export/excel")
    public ResponseEntity<byte[]> exportExcel(@RequestBody ExcelExportRequest request) {
        try {
            if (request.getData() == null || request.getData().isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
            
            // Extract columns from first row
            List<String> columns = List.copyOf(request.getData().get(0).keySet());
            
            byte[] excelData = service.exportToExcel(columns, request.getData());
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "query_results.xlsx");
            
            return ResponseEntity.ok().headers(headers).body(excelData);
        } catch (Exception e) {
            System.out.println("Excel export error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    // Get database schema
    @GetMapping("/schema")
    public ResponseEntity<List<String>> getSchema() {
        try {
            return ResponseEntity.ok(service.getSchema());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    // Get query history
    @GetMapping("/history")
    public ResponseEntity<List<QueryHistory>> getHistory() {
        try {
            return ResponseEntity.ok(service.getHistory());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
