package com.businesslogic;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

// Simple repository - just one interface
@Repository
interface QueryHistoryRepository extends JpaRepository<QueryHistory, String> {
    
    @Query("SELECT q FROM QueryHistory q ORDER BY q.createdAt DESC")
    List<QueryHistory> findTop20ByOrderByCreatedAtDesc();
}
