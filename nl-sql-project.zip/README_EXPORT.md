# How to Run This Project on Another System

## 1. Prerequisites
Before running, ensure the new system has:
*   **Java 21** (Required for Backend) -> [Download Here](https://adoptium.net/)
*   **Node.js** (Required for Frontend) -> [Download Here](https://nodejs.org/)

## 2. Setup (One Time)
1.  Unzip the folder.
2.  Open a terminal inside the project folder.
3.  Install Frontend Dependencies:
    ```bash
    cd frontend
    npm install
    cd ..
    ```

## 3. Run the App
Simply run the unified start script:
```bash
./start-all.sh
```

## 4. Troubleshooting
*   **Permission Denied**: Run `chmod +x start-all.sh start-backend.sh backend/gradlew`
*   **Port In Use**: The script usually handles this, but you can manually kill ports 8080/5173.
*   **API Key**: The `GROQ_API_KEY` is configured in `backend/src/main/resources/application.properties`. If the key hits a limit, generate a new free one at [console.groq.com](https://console.groq.com).

## 5. Architecture
*   **Frontend**: React + Vite (Port 5173)
*   **Backend**: Spring Boot + H2 Database (Port 8080)
*   **AI**: Groq API (Llama 3)
