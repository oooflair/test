#!/bin/bash

# Start Frontend Script
# This script starts the React frontend development server

echo "🚀 Starting Frontend Server..."
echo "================================"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18 or higher"
    exit 1
fi

# Navigate to frontend directory
cd "$(dirname "$0")/frontend"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Start the development server
echo "✅ Dependencies ready!"
echo "🎯 Starting server on http://localhost:5173"
echo "   Press Ctrl+C to stop"
echo ""
npm run dev
