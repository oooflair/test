package com.businesslogic;

// All services in ONE file - much simpler for a fresher!
// Instead of 5 separate service files, everything is here

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;

// ========== MAIN SERVICE - Handles everything ==========
@Service
class MainService {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private QueryHistoryRepository repository;
    
    @Autowired
    private DataSource dataSource;
    
    @Value("${groq.api.key}")
    private String groqApiKey;
    
    private HttpClient httpClient = HttpClient.newHttpClient();
    private Gson gson = new Gson();
    private Map<String, QueryResponse> queryCache = new HashMap<>();
    
    // Dangerous SQL patterns
    private static final Pattern DANGEROUS_KEYWORDS = Pattern.compile(
        "(?i).*(DROP|DELETE|UPDATE|INSERT|ALTER|CREATE|TRUNCATE|EXEC|EXECUTE).*"
    );
    
    // Process a natural language query - MAIN METHOD
    public QueryResponse processQuery(QueryRequest request) {
        String queryId = UUID.randomUUID().toString();
        QueryResponse response = new QueryResponse();
        response.setQueryId(queryId);
        response.setQuestion(request.getQuestion());
        response.setTimestamp(LocalDateTime.now());
        
        try {
            // Step 1: Generate SQL using OpenAI
            String sql = generateSQL(request.getQuestion());
            if (sql == null) {
                response.setStatus("ERROR");
                response.setErrorMessage("Failed to generate SQL");
                return response;
            }
            response.setGeneratedSQL(sql);
            
            // Step 2: Validate SQL
            String error = validateSQL(sql);
            if (error != null) {
                response.setStatus("INVALID");
                response.setErrorMessage(error);
                saveHistory(request.getQuestion(), sql, "INVALID", null, 0L, error);
                return response;
            }
            
            // Add LIMIT
            if (!sql.toUpperCase().contains("LIMIT")) {
                sql = sql + " LIMIT 10000";
            }
            response.setGeneratedSQL(sql);
            
            // Step 3: Execute query
            long startTime = System.currentTimeMillis();
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
            long executionTime = System.currentTimeMillis() - startTime;
            
            // Get columns
            List<String> columns = new ArrayList<>();
            if (!rows.isEmpty()) {
                columns.addAll(rows.get(0).keySet());
            }
            
            // Build response
            response.setStatus("SUCCESS");
            response.setColumns(columns);
            response.setRows(rows);
            response.setRowCount(rows.size());
            response.setExecutionTimeMs(executionTime);
            
            // Cache for Excel
            queryCache.put(queryId, response);
            
            // Save history
            saveHistory(request.getQuestion(), sql, "SUCCESS", rows.size(), executionTime, null);
            
        } catch (Exception e) {
            response.setStatus("ERROR");
            response.setErrorMessage("Error: " + e.getMessage());
        }
        
        return response;
    }
    
    // Generate SQL using Groq API (Llama 3 - High Free Tier!)
    private String generateSQL(String question) {
        try {
            // Build the prompt
            String prompt = "You are a SQL expert. Generate SIMPLE, valid SQL SELECT queries for H2 database.\n\n" +
                "CRITICAL RULES:\n" +
                "1. Generate ONLY SELECT queries\n" +
                "2. Return ONLY the SQL query, no explanations or markdown\n" +
                "3. Keep queries SIMPLE - avoid complex date functions\n" +
                "4. For year filtering: Use YEAR(order_date) = 2025\n" +
                "5. For date ranges: Use order_date >= '2025-01-01' AND order_date <= '2025-12-31'\n" +
                "6. Do NOT use: DATEADD, TRUNC, STRFTIME, or other complex functions\n\n" +
                "Database Schema (use ONLY these exact column names):\n" +
                "- customers: customer_id, customer_name, email, region, created_at\n" +
                "- products: product_id, product_name, category, price\n" +
                "- orders: order_id, customer_id, order_date, revenue, status\n" +
                "- order_items: order_item_id, order_id, product_id, quantity, unit_price\n\n" +
                "Example queries:\n" +
                "- SELECT * FROM customers WHERE region = 'North'\n" +
                "- SELECT * FROM orders WHERE YEAR(order_date) = 2025\n" +
                "- SELECT * FROM orders WHERE revenue > 1000000\n\n" +
                "Question: " + question;
            
            // Build JSON request for Groq (OpenAI format)
            JsonObject requestBody = new JsonObject();
            requestBody.addProperty("model", "llama-3.3-70b-versatile"); // Use Llama 3.3 (Latest supported)
            requestBody.addProperty("temperature", 0.1);
            
            JsonArray messages = new JsonArray();
            JsonObject message = new JsonObject();
            message.addProperty("role", "user");
            message.addProperty("content", prompt);
            messages.add(message);
            
            requestBody.add("messages", messages);
            
            // Call Groq API
            String url = "https://api.groq.com/openai/v1/chat/completions";
            // System.out.println("Calling Groq API: " + url);
            
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + groqApiKey)
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(requestBody)))
                .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            System.out.println("Groq API Status Code: " + response.statusCode());
            
            if (response.statusCode() != 200) {
                System.out.println("Groq API ERROR: " + response.body());
                return null;
            }
            
            // Parse response (OpenAI format)
            // System.out.println("Groq API Success Response: " + response.body());
            JsonObject responseJson = gson.fromJson(response.body(), JsonObject.class);
            String sqlResponse = responseJson
                .getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content").getAsString();
            
            // Clean up response
            sqlResponse = sqlResponse.trim();
            sqlResponse = sqlResponse.replaceAll("```sql\\n?", "");
            sqlResponse = sqlResponse.replaceAll("```\\n?", "");
            
            return sqlResponse.trim();
            
        } catch (Exception e) {
            System.out.println("Error generating SQL: " + e.getMessage());
            return null;
        }
    }
    
    // Validate SQL - simple regex check
    private String validateSQL(String sql) {
        if (sql == null || sql.trim().isEmpty()) {
            return "SQL is empty";
        }
        
        String trimmed = sql.trim().toUpperCase();
        
        if (!trimmed.startsWith("SELECT")) {
            return "Only SELECT queries allowed";
        }
        
        if (DANGEROUS_KEYWORDS.matcher(trimmed).matches()) {
            return "Forbidden SQL operations detected";
        }
        
        return null; // Valid
    }
    
    // Save to history
    private void saveHistory(String question, String sql, String status, 
                            Integer rowCount, Long executionTime, String error) {
        try {
            QueryHistory history = new QueryHistory();
            history.setQuestion(question);
            history.setGeneratedSql(sql);
            history.setStatus(status);
            history.setRowCount(rowCount);
            history.setExecutionTimeMs(executionTime);
            history.setErrorMessage(error);
            repository.save(history);
        } catch (Exception e) {
            System.out.println("Failed to save history: " + e.getMessage());
        }
    }
    
    // Get cached query for Excel
    public QueryResponse getCachedQuery(String queryId) {
        return queryCache.get(queryId);
    }
    
    // Get history
    public List<QueryHistory> getHistory() {
        return repository.findTop20ByOrderByCreatedAtDesc();
    }
    
    // Export to Excel
    public byte[] exportToExcel(List<String> columns, List<Map<String, Object>> rows) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Query Results");
            
            // Header row
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < columns.size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns.get(i));
            }
            
            // Data rows
            for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
                Row row = sheet.createRow(rowIndex + 1);
                Map<String, Object> rowData = rows.get(rowIndex);
                
                for (int colIndex = 0; colIndex < columns.size(); colIndex++) {
                    Cell cell = row.createCell(colIndex);
                    Object value = rowData.get(columns.get(colIndex));
                    
                    if (value == null) {
                        cell.setCellValue("");
                    } else if (value instanceof Number) {
                        cell.setCellValue(((Number) value).doubleValue());
                    } else {
                        cell.setCellValue(value.toString());
                    }
                }
            }
            
            // Auto-size columns
            for (int i = 0; i < columns.size(); i++) {
                sheet.autoSizeColumn(i);
            }
            
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to create Excel: " + e.getMessage());
        }
    }
    
    // Get database schema - only business tables
    public List<String> getSchema() {
        List<String> tables = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData metaData = conn.getMetaData();
            try (ResultSet rs = metaData.getTables(null, null, "%", new String[]{"TABLE"})) {
                while (rs.next()) {
                    String tableName = rs.getString("TABLE_NAME");
                    
                    // Skip all system tables - only show business tables
                    if (tableName.startsWith("QUERY_HISTORY") ||
                        tableName.startsWith("INFORMATION_") ||
                        tableName.equals("CONSTANTS") ||
                        tableName.equals("ENUM_VALUES") ||
                        tableName.equals("INDEXES") ||
                        tableName.equals("INDEX_COLUMNS") ||
                        tableName.equals("IN_DOUBT") ||
                        tableName.equals("LOCKS") ||
                        tableName.equals("QUERY_STATISTICS") ||
                        tableName.equals("RIGHTS") ||
                        tableName.equals("ROLES") ||
                        tableName.equals("SESSIONS") ||
                        tableName.equals("SESSION_STATE") ||
                        tableName.equals("SETTINGS") ||
                        tableName.equals("SYNONYMS") ||
                        tableName.equals("USERS")) {
                        continue; // Skip system tables
                    }
                    
                    tables.add(tableName);
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading schema: " + e.getMessage());
        }
        return tables;
    }
}
