import { useState } from 'react';
import axios from 'axios';
import './App.css';

const API_BASE_URL = 'http://localhost:8080/api';

function App() {
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [schema, setSchema] = useState([]);
  const [showSchema, setShowSchema] = useState(false);

  const exampleQueries = [
    "Show total sales by region for last quarter where revenue > 1M",
    "List top 10 customers by revenue in 2024",
    "What are the most popular products?",
    "Show all orders from December 2024"
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim()) {
      setError('Please enter a question');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await axios.post(`${API_BASE_URL}/query`, {
        question: question,
        includeExplanation: true
      });

      if (response.data.status === 'SUCCESS') {
        console.log('Query SUCCESS! Response:', response.data);
        console.log('Row count:', response.data.rowCount);
        console.log('Rows:', response.data.rows);
        setResult(response.data);
      } else {
        console.log('Query FAILED:', response.data);
        setError(response.data.errorMessage || 'Query failed');
      }
    } catch (err) {
      console.error('API Error:', err);
      setError(err.response?.data?.errorMessage || 'Failed to execute query');
    } finally {
      setLoading(false);
    }
  };

  const handleShowSchema = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/schema`);
      setSchema(response.data);
      setShowSchema(true);
    } catch (err) {
      setError('Failed to load schema');
    }
  };

  const handleDownloadExcel = async () => {
    if (!result || !result.rows || result.rows.length === 0) {
      setError('No results to export');
      return;
    }

    try {
      // Send the already-generated SQL and data, don't re-query AI!
      const response = await axios.post(`${API_BASE_URL}/export/excel`, {
        sql: result.generatedSql,
        data: result.rows
      }, {
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'query_results.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Excel download error:', err);
      setError('Failed to download Excel file');
    }
  };

  return (
    <div className="container">
      <header>
        <h1>Natural Language to SQL</h1>
        <p>Ask questions about your data in plain English</p>
      </header>

      <main>
        <div className="query-section">
          <form onSubmit={handleSubmit}>
            <label>Ask a Question:</label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g., What are the most popular products?"
              rows="4"
            />

            <div className="button-group">
              <button type="submit" disabled={loading} className="btn-primary">
                {loading ? 'Processing...' : 'Run Query'}
              </button>
              <button type="button" onClick={handleShowSchema} className="btn-secondary">
                Show Schema
              </button>
            </div>
          </form>

          <div className="examples">
            <p><strong>Try these examples:</strong></p>
            {exampleQueries.map((query, index) => (
              <button
                key={index}
                onClick={() => setQuestion(query)}
                className="example-btn"
              >
                {query}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="error-box">
            {error}
          </div>
        )}

        {result && (
          <div className="results-section">
            <div className="results-header">
              <h2>Results ({result.rowCount} rows)</h2>
              <button onClick={handleDownloadExcel} className="btn-download">
                Download Excel
              </button>
            </div>

            <div className="sql-box">
              <strong>Generated SQL:</strong>
              <pre>{result.generatedSql}</pre>
            </div>

            {result.rows && result.rows.length > 0 && (
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      {Object.keys(result.rows[0]).map((key) => (
                        <th key={key}>{key}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {result.rows.map((row, idx) => (
                      <tr key={idx}>
                        {Object.values(row).map((value, i) => (
                          <td key={i}>{value !== null ? String(value) : 'NULL'}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {showSchema && schema.length > 0 && (
          <div className="schema-section">
            <h2>Database Schema</h2>
            <div className="schema-list">
              {schema.map((table, index) => (
                <div key={index} className="schema-item">
                  {table}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
