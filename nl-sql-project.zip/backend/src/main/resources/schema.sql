-- Sample Database Schema for Business Intelligence Demo
-- This creates tables for customers, orders, products, and order items

-- Customers table: stores customer information
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    region VARCHAR(50),
    created_at DATE
);

-- Products table: stores product catalog
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10, 2)
);

-- Orders table: stores customer orders
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    revenue DECIMAL(10, 2),
    status VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Order Items table: stores individual items in each order
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT,
    unit_price DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Insert sample customers
INSERT INTO customers (customer_name, email, region, created_at) VALUES
('Acme Corp', 'contact@acme.com', 'North', '2023-01-15'),
('Globex Industries', 'info@globex.com', 'South', '2023-02-20'),
('Initech Solutions', 'sales@initech.com', 'East', '2023-03-10'),
('Umbrella Corporation', 'contact@umbrella.com', 'West', '2023-04-05'),
('Stark Industries', 'info@stark.com', 'North', '2023-05-12'),
('Wayne Enterprises', 'contact@wayne.com', 'East', '2023-06-18'),
('Oscorp', 'sales@oscorp.com', 'South', '2023-07-22'),
('Cyberdyne Systems', 'info@cyberdyne.com', 'West', '2023-08-30'),
('Massive Dynamic', 'contact@massive.com', 'North', '2023-09-14'),
('Tyrell Corporation', 'sales@tyrell.com', 'South', '2023-10-25');

-- Insert sample products
INSERT INTO products (product_name, category, price) VALUES
('Enterprise Software License', 'Software', 5000.00),
('Cloud Storage (1TB)', 'Cloud Services', 150.00),
('Consulting Package', 'Services', 10000.00),
('API Access Premium', 'Software', 2500.00),
('Data Analytics Tool', 'Software', 7500.00),
('Security Suite', 'Software', 3000.00),
('Training Program', 'Services', 1500.00),
('Support Contract', 'Services', 2000.00),
('Mobile App License', 'Software', 1000.00),
('Integration Module', 'Software', 4000.00);

-- Insert sample orders for Q4 2024 and Q1 2025
INSERT INTO orders (customer_id, order_date, revenue, status) VALUES
-- Q4 2024 orders
(1, '2024-10-05', 1250000, 'completed'),
(2, '2024-10-12', 980000, 'completed'),
(3, '2024-10-20', 750000, 'completed'),
(4, '2024-11-03', 1500000, 'completed'),
(5, '2024-11-15', 2100000, 'completed'),
(6, '2024-11-22', 890000, 'completed'),
(7, '2024-12-01', 1350000, 'completed'),
(8, '2024-12-10', 1100000, 'completed'),
(9, '2024-12-18', 950000, 'completed'),
(10, '2024-12-28', 1200000, 'completed'),
-- Q1 2025 orders
(1, '2025-01-08', 1400000, 'completed'),
(2, '2025-01-15', 850000, 'completed'),
(3, '2025-01-22', 920000, 'pending'),
(4, '2025-01-28', 1650000, 'pending'),
    -- Q4 2025 orders (for "last quarter" queries - Oct/Nov/Dec 2025)
    (1, '2025-10-10', 1800000, 'completed'),
    (2, '2025-10-18', 1250000, 'completed'),
    (3, '2025-11-05', 1600000, 'completed'),
    (4, '2025-11-20', 2200000, 'completed'),
    (5, '2025-12-08', 1900000, 'completed'),
    (6, '2025-12-15', 1450000, 'completed'),
    (7, '2025-10-25', 2100000, 'completed'),
    (8, '2025-11-12', 3000000, 'completed'),
    (9, '2025-12-28', 1500000, 'completed'),
    (10, '2025-12-05', 1800000, 'completed'),
    -- Q1 2026 orders (recent data)
    (7, '2026-01-05', 2500000, 'completed'),
    (8, '2026-01-12', 1750000, 'completed'),
    (9, '2026-01-20', 1300000, 'completed'),
    (10, '2026-01-25', 2100000, 'completed');

-- Insert sample order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
-- Order 1 items
(1, 1, 50, 5000.00),
(1, 3, 20, 10000.00),
(1, 5, 30, 7500.00),
-- Order 2 items
(2, 2, 100, 150.00),
(2, 4, 25, 2500.00),
(2, 6, 40, 3000.00),
-- Order 3 items
(3, 1, 30, 5000.00),
(3, 7, 50, 1500.00),
-- Order 4 items
(4, 3, 30, 10000.00),
(4, 5, 40, 7500.00),
(4, 8, 50, 2000.00),
-- Order 5 items
(5, 1, 80, 5000.00),
(5, 3, 40, 10000.00),
(5, 5, 60, 7500.00),
-- More items for other orders
(6, 2, 80, 150.00),
(6, 4, 20, 2500.00),
(6, 9, 30, 1000.00),
(7, 1, 60, 5000.00),
(7, 6, 50, 3000.00),
(7, 10, 40, 4000.00),
(8, 3, 25, 10000.00),
(8, 5, 35, 7500.00),
(8, 8, 40, 2000.00),
(9, 1, 40, 5000.00),
(9, 4, 30, 2500.00),
(9, 7, 45, 1500.00),
(10, 3, 30, 10000.00),
(10, 5, 40, 7500.00),
(10, 6, 35, 3000.00);
