#!/bin/bash

echo "=================================================="
echo "   🚀 STARTING FULL STACK APP (Business Logic)    "
echo "=================================================="

# Function to kill process by port
kill_process_on_port() {
    local port=$1
    local pid=$(lsof -ti:$port)
    if [ -n "$pid" ]; then
        echo "🔪 Port $port is in use (PID: $pid). Killing it..."
        kill -9 $pid
    else
        echo "✅ Port $port is free."
    fi
}

# 1. Kill duplicate processes
echo ""
echo "🛑 Checking ports..."
kill_process_on_port 8080
kill_process_on_port 5173

# 2. Start Backend
echo ""
echo "☕ Starting Backend (Spring Boot)..."
# We stream output to backend.log so it doesn't clutter the main terminal, but we print errors
cd backend
./gradlew bootRun > ../backend.log 2>&1 &
BACKEND_PID=$!
cd ..
echo "   PID: $BACKEND_PID"
echo "   Logs: backend.log"

# 3. Wait for backend to warm up slightly
echo "⏳ Waiting 5 seconds for backend to initialize..."
sleep 5

# 4. Start Frontend
echo ""
echo "🎨 Starting Frontend (Vite)..."
cd frontend
npm run dev > ../frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..
echo "   PID: $FRONTEND_PID"
echo "   Logs: frontend.log"

echo ""
echo "=================================================="
echo "✅ APP STARTED SUCCESSFULLY!"
echo "   🌍 Frontend: http://localhost:5173"
echo "   ⚙️ Backend:  http://localhost:8080"
echo "=================================================="
echo "📝 To view logs, run in another terminal:"
echo "   tail -f backend.log"
echo "   tail -f frontend.log"
echo "=================================================="
echo "🛑 Press Ctrl+C to stop everything properly"
echo "=================================================="

# Helper to kill processes on exit
cleanup() {
    echo ""
    echo "🛑 Shutting down..."
    kill $BACKEND_PID
    kill $FRONTEND_PID
    echo "👋 Bye!"
    exit 0
}

# Trap SIGINT (Ctrl+C)
trap cleanup SIGINT

# Wait indefinitely
wait
