#!/bin/bash

# Gradle Wrapper Script
# This script starts the Spring Boot backend using Gradle

echo "🚀 Starting Backend Server with Gradle..."
echo "========================================"

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "❌ Java is not installed. Please install Java 21"
    exit 1
fi

# Check Java version
JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
echo "📌 Java version detected: $JAVA_VERSION"

if [ "$JAVA_VERSION" -lt 21 ]; then
    echo "⚠️  WARNING: Java 21 or higher is recommended. You have Java $JAVA_VERSION"
fi

# Navigate to backend directory
cd "$(dirname "$0")/backend"

# Check if Groq API key is set
if [ -z "$GROQ_API_KEY" ]; then
    echo "ℹ️  INFO: GROQ_API_KEY is not set."
    echo "   Using the default key provided in application.properties"
    echo ""
fi

# Check if gradlew exists, if not initialize gradle wrapper
if [ ! -f "./gradlew" ]; then
    echo "📦 Initializing Gradle wrapper..."
    gradle wrapper --gradle-version 8.5
fi

# Make gradlew executable
chmod +x gradlew

# Build and run
echo "📦 Building project with Gradle..."
./gradlew clean build -x test

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "🎯 Starting server on http://localhost:8080"
    echo "   Press Ctrl+C to stop"
    echo ""
    ./gradlew bootRun
else
    echo "❌ Build failed. Please check the errors above."
    exit 1
fi
