package com.businesslogic;

// All models in one file - simpler for a fresher to understand
// Instead of having separate files for each class

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

// ========== REQUEST/RESPONSE CLASSES ==========

// Request from frontend
class QueryRequest {
    @NotBlank(message = "Question cannot be empty")
    private String question;
    private Boolean includeExplanation;
    
    public QueryRequest() {}
    
    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }
    public Boolean getIncludeExplanation() { return includeExplanation; }
    public void setIncludeExplanation(Boolean includeExplanation) { this.includeExplanation = includeExplanation; }
}

// Response to frontend
class QueryResponse {
    private String queryId;
    private String question;
    private String generatedSQL;
    private List<String> columns;
    private List<Map<String, Object>> rows;
    private Integer rowCount;
    private Long executionTimeMs;
    private String explanation;
    private LocalDateTime timestamp;
    private String status;
    private String errorMessage;
    
    public QueryResponse() {}
    
    public String getQueryId() { return queryId; }
    public void setQueryId(String queryId) { this.queryId = queryId; }
    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }
    public String getGeneratedSQL() { return generatedSQL; }
    public void setGeneratedSQL(String generatedSQL) { this.generatedSQL = generatedSQL; }
    public List<String> getColumns() { return columns; }
    public void setColumns(List<String> columns) { this.columns = columns; }
    public List<Map<String, Object>> getRows() { return rows; }
    public void setRows(List<Map<String, Object>> rows) { this.rows = rows; }
    public Integer getRowCount() { return rowCount; }
    public void setRowCount(Integer rowCount) { this.rowCount = rowCount; }
    public Long getExecutionTimeMs() { return executionTimeMs; }
    public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
}

// Request for Excel export (direct data, no AI re-query)
class ExcelExportRequest {
    private String sql;
    private List<Map<String, Object>> data;
    
    public ExcelExportRequest() {}
    
    public String getSql() { return sql; }
    public void setSql(String sql) { this.sql = sql; }
    public List<Map<String, Object>> getData() { return data; }
    public void setData(List<Map<String, Object>> data) { this.data = data; }
}


// ========== DATABASE ENTITY ==========

@Entity
@Table(name = "query_history")
class QueryHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false, length = 1000)
    private String question;
    
    @Column(nullable = false, columnDefinition = "TEXT")
    private String generatedSql;
    
    @Column(nullable = false)
    private String status;
    
    private Integer rowCount;
    private Long executionTimeMs;
    
    @Column(columnDefinition = "TEXT")
    private String errorMessage;
    
    @Column(nullable = false)
    private LocalDateTime createdAt;
    
    public QueryHistory() {
        this.createdAt = LocalDateTime.now();
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }
    public String getGeneratedSql() { return generatedSql; }
    public void setGeneratedSql(String generatedSql) { this.generatedSql = generatedSql; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Integer getRowCount() { return rowCount; }
    public void setRowCount(Integer rowCount) { this.rowCount = rowCount; }
    public Long getExecutionTimeMs() { return executionTimeMs; }
    public void setExecutionTimeMs(Long executionTimeMs) { this.executionTimeMs = executionTimeMs; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
